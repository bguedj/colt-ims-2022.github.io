---
layout: workshop
title: Reinforcement learning
room: 
# date:
starttime: 
endtime: 
organizers:
  - given: Alessandro
    family: Lazaric
    affiliation: FAIR (Paris)
  - given: Ian 
    family: Osband
    affiliation: DeepMind (London)
---