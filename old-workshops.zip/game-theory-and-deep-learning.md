---
layout: workshop
title: Game theory and deep learning
room: 
# date:
starttime: 
endtime: 
organizers:
  - given: Simon
    family: Lacoste-Julien
    affiliation: MILA and University of Montréal
  - given: Ioannis 
    family: Mitliagkas
    affiliation: MILA and University of Montréal
---
