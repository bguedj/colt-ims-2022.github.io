---
layout: workshop
title: Fashion AI
room: 
# date:
starttime: 
endtime: 
organizers:
  - given: Ralf
    family: Herbrich
    affiliation: Zalando
---
