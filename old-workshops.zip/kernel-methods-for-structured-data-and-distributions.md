---
layout: workshop
title: Kernel methods for structured data and distributions
room: 
# date:
starttime: 
endtime: 
organizers:
  - given: Zoltan  
    family: Szabo
    affiliation: École Polytechnique (Paris)
  - given: Alessandro 
    family: Rudi
    affiliation: INRIA (Paris)
---