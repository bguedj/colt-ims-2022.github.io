---
layout: workshop
title: Fair and explainable machine learning
room: 
# date:
starttime: 
endtime: 
organizers:
  - given: Silvia
    family: Chiappa
    affiliation: DeepMind (London)
---
