---
layout: workshop
title: Robust and adversarial learning
room: 
# date:
starttime: 
endtime: 
organizers:
  - given: Matthias
    family: Hein
    affiliation: University of Tübingen
---
